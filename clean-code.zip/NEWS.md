# peskas.dashboard 2.5.0

## AskFish

- A button in the top bar opens AskFish, an assistant that answers questions about the country's data in a side panel: its words, the figures behind them, its charts drawn like the dashboard's own, and the data it read. It offers a few questions to start from. The conversation stays open while the reader moves between pages.
- Every question may use all of the country's data. The districts and months picked on screen go along, and AskFish uses them when a question asks about the selection.
- Figures are rounded and coloured as on the pages. AskFish knows the estimates of both methods, GPS tracker and FAO ARTFISH, and a chart of one wears that method's colour and name. Its words are in English whatever the page language.
- What AskFish knows about the data, each measure's meaning, unit and how it adds up, comes from the Peskas data dictionary, the one description of the data the pages are checked against, instead of a list written once by hand. When AskFish needs a figure across months, districts, gears or species, the dashboard works it out with the pages' own code (averages weighted by the landings behind each figure, estimates added up over the district-months both methods estimate), so an answer gives the page's number.
- AskFish is a separate service. The dashboard asks it from its server, never from the browser, and AskFish reads the data back through the dashboard, with one secret shared both ways. It is on only where `ASKFISH_URL` and `ASKFISH_SHARED_TOKEN` are set; elsewhere nothing changes and the chat isn't built.

## Changes

- On a phone, the flag next to the country name is hidden, to leave room in the top bar.
# peskas.dashboard 2.4.2

## Changes

- Mozambique: the district filter, the region groups and the coverage table now include Maganja Da Costa (Central) and Mossuril (North), where DINAPA enumerators collect data since October 2026. Namacurra and Nacala stay, with the data collected there before.

# peskas.dashboard 2.4.1

## Changes

- A deployment can also send its visits, clicks and the dashboard's own events to PostHog (EU cloud), beside Google Analytics, with session replays if they are turned on in PostHog. A page or chart that crashes is reported to PostHog's error tracking. It is on only where `VITE_POSTHOG_KEY` is set, first on Zanzibar as a trial, and the other deployments don't download it. ANALYTICS.md has the details.

# peskas.dashboard 2.4.0

## How much of each species all boats land

- On Species and sizes, the chart of the species that make up the catch now shows two bars for each species group: its share of the recorded catch, and, in the ARTFISH gold, its share of the catch all the boats land, as the FAO ARTFISH method estimates it, with the tonnes. Where the two differ shows at a glance. The groups shown are the 15 largest by either measure.
- The two can rank a species differently: the estimate counts each district and kind of boat and gear by its boats, not by how much catch was recorded there. The chart's explanation says so in a few lines; Data and methods has the rest under the FAO ARTFISH method, with why the estimate's total can be higher than the ARTFISH catch on the Catch page, which adds up only the districts and months both methods estimate. Under the chart, a warning says what share of the districts and months the estimate covers, and how much of the recorded catch those hold.
- The table of species by district can switch from the recorded catch to the same estimate, in tonnes and in gold. It says how many districts have no estimate in the months selected, and that a dash means none for that species there.
- Data and methods describes it under the FAO ARTFISH method.
- Until the next data update publishes these estimates, the chart shows the recorded catch alone and the table has no switch. If the estimates can't be loaded, both say so and show the recorded catch.

## The two methods by their colours, wherever they are named

- In explanations and notes, the GPS tracker method is named in wine-red and the FAO ARTFISH method in gold, as in the charts, each a link to how it works on Data and methods. The gold and the wine are shaded a little where needed, so the words are as easy to read as the text around them.
- The warning that estimates cover only part of the districts and months is a link to where Data and methods explains it.

## Changes

- A link to a section of Data and methods now lands with its title in view; before, the top bar covered it.

# peskas.dashboard 2.3.3

## The Peskas logo

- The top bar shows the official Peskas logo, a fish made of small hexagons that turn from light at the tail to dark at the head, with a coral eye, and the word "peskas", followed by the country: "peskas Zanzibar". It replaces the sailboat and "PESKAS™". It has its own colours in the light and the dark theme, and on a phone the fish stands alone.
- The browser tab shows the same fish, in the browser's light or dark colours, and a phone that saves the dashboard to its home screen gets it as the app icon.
- A link to the dashboard shared in a chat or on social media now shows a card with the logo and the country.

# peskas.dashboard 2.3.2

## Estimated totals say what they cover

- An estimated total adds up only the districts and months that have an estimate, which is often a small part of those selected. The dashboard now says so: a warning gives the share the estimates cover (for example "Estimates cover 16% of districts and months"), under the chart of an estimate or, while another figure is charted, under the figures at the top.
- The trend of an estimate says in its subtitle how many districts a month counts on average ("About 5 of 20 districts a month, total") and shows the count under each month, in the tooltip and in the CSV. A note under the chart reads one of the numbers out and says why a district can be missing from a month: too few surveyed landings, or no tracked boats.
- On the Catch and Revenue pages the figures at the top are the same size, and the line saying that estimates show no change on a year earlier is gone from there.
- Data and methods explains this next to how the two methods are compared, and under the limits of each estimate.

# peskas.dashboard 2.3.1

## Each method has its own colour

- Estimates by the GPS tracker method are now wine-red and those by the FAO ARTFISH method gold, in every figure, chart, table and map. Cyan is left to the figures recorded at the landings, so a colour means one thing on every page. The pair was chosen so that red-green colour-blind readers can tell the two methods apart, in the light and the dark theme.

## Changes

- The month-by-month pattern of an estimate, at the foot of the Catch and Revenue pages, always has the switch between the two methods. A method with under two years of data says so in place of its table.

# peskas.dashboard 2.3.0

## Two estimates of total catch and revenue, side by side

- Estimated catch, revenue and fishing trips now show two figures wherever they appear: the GPS tracker method, as before, and FAO's ARTFISH method, which raises the landing survey with the boat census and the days fishers say they fished. Each method has its own name and colour in every figure, chart and table.
- The two are compared like with like: their totals and trend lines add up only the districts and months both methods estimate, or each its own where they share none. The district charts draw every month each method estimates, and districts without tracked boats appear with their FAO ARTFISH figure.
- The district map and the month-by-month pattern show one method at a time, in its own colours, with a switch between the two. In the district ranking each method has its own bars.
- Estimates by both methods are rounded everywhere: figures, tables, charts and the map. FAO ARTFISH figures show no change on a year earlier, as their precision isn't shown yet.
- Data and methods explains both methods side by side, each in its own colour with a diagram, says why their figures differ, and links FAO's OPEN ARTFISH toolkit.
- Data and methods opens with a contents card, and each section is marked with its icon and a line on what it covers.

## Changes

- The GPS tracker totals can be lower than before: districts and months the FAO ARTFISH method doesn't estimate are left out, so the two totals compare.
- The trend of an estimate shows its two methods instead of the same months a year earlier.
- The estimates card on the home page reads left to right: the figures across, their confidence and rounding underneath.
- A selected figure on the Catch and Revenue pages no longer covers the top bar when the page scrolls.
- The district comparison on the home page also ranks and maps estimated revenue, and its measures scroll sideways on a phone instead of being cut off.
- The fishing-effort map says that it counts only the time spent fishing, not the travel to and from the fishing grounds.
- Chart explanations for estimates, fish sizes, gears and the district comparison are shorter and say what each chart shows. Data and methods no longer says the GPS tracker estimates leave out trips longer than 48 hours: those trips now count.

# peskas.dashboard 2.2.0

## Clearer pages: the answer first, one district at a time

- Every page opens with its name, the question it answers, its filters, and one line saying how many landings, districts and months its figures rest on and when the data was last updated.
- The home page leads with what the surveyed landings show (catch rate, catch and revenue per trip, landings surveyed), each against the same months a year earlier. Estimated totals for all boats sit together with how confident they are; while few boats carry a tracker they are rounded and their change is not shown.
- Districts are compared in one ranked table with their change on a year earlier. Select a district to see it on its own. Districts with no surveyed landings are listed once instead of filling the table with dashes.
- On the Catch and Revenue pages, the figures at the top choose what the charts show: the selected districts as one line against the same months a year earlier, then each district in its own small chart on the same scale.
- Species show their common names. Species and sizes has three tabs: what is caught, at what size (with every measured species ranked by how much of its catch is below the size at which it first reproduces), and the food web.
- The Fishing gear page compares every gear in one table: how much it is used, what it catches and earns per hour, how much of its catch is below maturity size, and its main species.
- Vulnerable species opens with four figures. Data and methods draws how the figures are made and estimated, and sets out each survey, every measure and the chart symbols in one place each.
- A page's address keeps its time range, districts and measure, so a shared link opens the same view.
- The fishing-effort map shows the whole Mozambique coast legibly, in its own section.
- The fishing-effort map shows the same fishing activity as the Peskas Coasts regional map, for this country only: the hours boats spent fishing, told apart from travel, with the fishing grounds they keep returning to outlined. It opens tilted so the columns show their height, and hovering over a fishing ground highlights it and shows its figures.
- Pages print on landscape A4 with their time range and districts written on them.
- The top bar shows the partner the dashboard is developed with, by logo and name, beside the Peskas brand: ZAFIRI in Zanzibar, KEFS in Kenya and DINAPA (National Directorate of Fisheries and Aquaculture) in Mozambique, linked to their websites where they have one. DINAPA has no logo yet, so its name shows on its own. Data and methods names the partner first.
- Data and methods and the chart explanations link the sources and organisations they name (FishBase, SeaLifeBase, the IUCN Red List, Pelagic Data Systems, the partner, the Peskas Management Platform). The Data and methods contact section sets out where to ask questions, the Peskas Management Platform for survey teams, the Peskas Fishery Data API and Peskas itself.

## Changes

- Every figure covers complete months: the current month is left out until its data is in, as the home page already did.
- Pages open on all the data (all time) rather than the last 6 months. Pick 3, 6 or 12 months to compare with the same months a year earlier.
- The month-by-month pattern (seasonality) appears once the selected districts have two years of data.
- Large numbers read "62 billion TZS" instead of "61,884.1M", in the page's language.
- Colours mean the same thing on every page and stay distinct for colour-blind readers; districts no longer have colours of their own.
- Mozambique opens on all its districts, like Zanzibar and Kenya.
- Buttons, links and the chosen figure look clickable, and popups and chart tooltips let the chart show through.
- The chosen time range and measure stand out in the accent colour, and the map legend shows which bands and layers are switched off.
- In the district-by-district panels, pointing at a month marks it in every panel and shows each district's value for that month beside its name, instead of a tooltip over every panel.
- Bars drawn in two shades (catch below maturity size, the vulnerability of a group of species) and the district panels have a legend, and the trend charts say how the districts are combined.

## Fixed

- Explanations checked against the pipelines that make the figures. Catch and revenue per unit effort are per hour of the trip as reported at landing, travel included, not per hour spent fishing. Length classes are described as they are (under 10 cm, then 5 cm wide to 30 cm, 10 cm to 1 m, wider above). Flagged records are said to be left out, without implying that a review brings them back. The size-at-maturity and gear explanations describe the charts they sit on.
- Months without data no longer show as dots along the top edge of the trend charts.
- The length chart draws each size class as wide as it is, so a wide class no longer looks like a large catch.
- In Kenya and Mozambique, the number of landings in a page's summary line now matches its figures.
- The species bar charts no longer repeat the species name in their tooltip.
- Mozambique's figures now include Mogincual, whose landings were left out.
- When the selected months have no landings, the figures at the top say so instead of leaving an empty space.
- A chart that fails to load now says so instead of reporting no data, and the fishing map says when its data is loading, missing or can't be drawn in the browser.
- For estimated totals, the grey line behind each district panel is the average district rather than the sum of all districts, which flattened every district's line.
- Data and methods now says that species information covers the Western and Eastern Indian Ocean, that length classes widen above 30 cm, and that in Zanzibar and Mozambique the catch weight is worked out from fish lengths or buckets.

## Removed

- The stacked bars of species by district and by gear, and the four separate gear charts.

---

# peskas.dashboard 2.1.0

## Dashboards that explain themselves

- New Fishing gear page: which gears are used, how much they catch and earn per hour, and how much of their catch is smaller than the size at which the fish first reproduce.
- New Vulnerable species page: catch by vulnerability to fishing, sharks and rays, and each species' IUCN Red List and CITES status.
- The About page is now Data and methods: where the data comes from, how every figure is calculated and its limits, a glossary, and a table of landings surveyed per district and month.
- Every chart asks the question it answers, has an ⓘ button explaining what it shows, how it is calculated and what it cannot tell you, a button to download its data (CSV), and a line saying how many landings it rests on, the latest month of data and whether that sample is small, medium or large.
- The home page shows headline figures for complete months, compared with the same months a year earlier, and says how confident each estimate is.
- New figures: catch and revenue per trip, estimated fishing trips, price per kg by species, what each gear catches, the mean trophic level of the catch, and the size of the catch: how much is below the size at which each species first reproduces, at its optimum size, or large spawners.
- Figures resting on fewer than 10 landings carry a warning sign; in the time series they are drawn as hollow points and in the district table they are greyed out.
- Pages print cleanly.

## Changes

- Averages across districts, months and gears count each value by the landings behind it, so a district with 5 landings no longer weighs as much as one with 500.
- Seasonality is a month-by-district table over every year of data. With less than two years of it, the table says it shows a single year rather than a seasonal pattern.
- Gear performance is a ranked bar chart with the number of landings per gear, instead of a treemap.
- Catch by species is labelled as recorded catch: it comes from the surveyed landings, not the total catch.
- "No. of fishers" is now "Fishers per trip", which is what it always measured.
- The fishing-effort map opens flat and says that it covers all time and only boats with GPS trackers.
- The Kenya dashboard opens on every district: the three it opened on have had almost no surveys this year.
- On the Kenya dashboard the sizes of the catch are drawn from the average length of the fish measured on each landing, which is what its survey records; the charts and the Data and methods page say so.

## Removed

- The "length distribution" chart, which showed how district averages differed rather than the sizes of fish.
- The "Beta" labels.

---

# peskas.dashboard 2.0.0

## Redesign

- A new look: one top bar holds the page links, language and theme switch (a side menu on phones), leaving the full width to the charts.
- Light theme by default, with a switch to dark.
- Filters fold into a "Filters" button on small screens.
- Pages open faster, and switching between them is almost instant.
- The home page summary cards sit in one scrollable row and say they cover the last 3 months.
- The home page map is larger, with the district ranking beside it; its legends and explanation no longer cover the map.
- Chart legends are clickable: tap a district or species to hide or show it.

## Bug Fixes

- Catch composition now follows the selected time range.
- Catch composition showed a single month per district and species; it now covers the whole selected period.
- "Top N species" now means the N species with the most catch, not the first N alphabetically.
- The home page region cards add up their districts' catch, revenue, landings and fishers instead of averaging them.
- Seasonality charts under "All time" average every year of data and show month names in the page language.
- The map showed "NaN" for visit and cell counts above 1,000.
- The length chart tooltip printed "cm kg" for total catch.
- The species picker could not be reopened after "Clear all".
- The district table labelled revenue in Tanzanian shillings for every country.
- Time series left out districts with no value in the first month.
- Charts showed an error instead of a prompt when no district was selected.
- The district table said "no data" when loading failed; it now shows an error.
- The Mapbox attribution is shown on the map again.
- The metric picked on the home map no longer resets after visiting the catch page.
- A chart that fails to draw shows an error in its own card instead of blanking the page; other page errors offer a reload button.
- The "page not found" page is shown in the page language.

## Removed

- Sign-in, password reset and user administration: the dashboards are open and need no account.
- The Map page, which had no data to show.
- The unfinished "Ask Data" page, which was never in the menu.

---

# peskas.dashboard 1.4.0

## Security

- **User management endpoints were unauthenticated beyond "is logged in"**: `user.delete`
  and `user.upsert` ran on `protectedProcedure` with no permission check — the delete
  handler's only guard was that a session carried an email, under a comment claiming it
  verified admin privileges. Any signed-in user could delete or modify any account,
  including changing their own group. Both now call `assertPermission()`. Existing
  administrators are unaffected: the "Manage users" menu entry was already gated on a
  stricter check (all of create/read/update/delete), so anyone who could see the link
  passes the narrower server-side checks.

- **File uploads accepted anonymous requests**: `/api/uploadthing` shipped the template's
  placeholder `const auth = (req) => ({ id: 'fakeId' })`, so both upload routes — including
  one accepting 256 MB video — were open to the public internet against the deployment's
  storage quota. The middleware now requires a NextAuth session.

- **Deactivated accounts could still sign in**: the `status === "inactive"` check sat after
  the successful-password `return` in the credentials provider, so it never ran for a valid
  password. It only fired on a *wrong* password, where it also leaked account status to an
  unauthenticated caller. The check now runs before the password is compared.

- **Single permission implementation**: `hasPermission()` moved from
  `apps/isomorphic-i18n/src/helpers/auth.ts` into `packages/api/src/lib/permissions.ts`, so
  the tRPC procedures and the UI read the same function. Previously only the UI had one,
  which is how the menu and the API came to disagree.

## Bug Fixes

- **Password reset emails linked to a different application**: the reset link hardcoded
  `https://peskas-next-umber.vercel.app` whenever `NODE_ENV === 'production'`, sending every
  country's users to an unrelated deployment. The base URL is now derived from
  `NEXTAUTH_URL`, falling back to `VERCEL_URL`, so each deployment links to itself.

- **Passwords were hashed twice**: `user.upsert` set `password` twice in one object literal —
  a cost-12 hash that was immediately overwritten by a cost-10 `hashSync`. The cost-12 work
  was computed and discarded, and the stored hash was the weaker one. Now hashed once at
  cost 12, and only when a password was actually supplied.

- **Social previews advertised the template**: `metaObject()` still returned
  `"Isomorphic Furyroad"` as the OpenGraph title suffix and site name, pointed `url` at
  `isomorphic-furyroad.vercel.app`, and served the template's banner from RedQ's S3 bucket.
  It now derives everything from `activeCountry`, so each country's link previews carry its
  own title, description, and locale.

- **`user.byId` crashed for users with no group**: `user?.groups[0].name` threw a TypeError
  once optional chaining short-circuited past the array index. Now `user?.groups?.[0]?.name`.

- **Middleware matched locales that do not exist**: the matcher listed `de|es|ar|he|zh`
  alongside the three real locales, routing requests for languages with no translation
  files. Trimmed to `en|sw|pt`.

- **`ask-data` page title hardcoded Zanzibar**: read `"Ask Data | Peskas Zanzibar"` on every
  deployment; now goes through `metaObject()`.

## Removed

- **Two unused applications**: `apps/isomorphic` and `apps/isomorphic-starter` were template
  variants with no deployment from this repository — confirmed against Vercel, where all
  three live projects (`peskas-dashboard-{zanzibar,kenya,mozambique}`) build
  `apps/isomorphic-i18n`. `apps/isomorphic` continues to exist in the separate `peskas-next`
  repository, so nothing is lost.

- **Cross-package imports reaching into a deleted app**: `packages/isomorphic-core` imported
  *upward* into `apps/isomorphic` from three files via relative paths. Two of them were
  reachable from the deployed app, so deleting the app without severing these first would
  have broken the build. `utils/uploadthing.ts` now takes its `OurFileRouter` type from the
  surviving app; `get-status-badge.tsx` and `product-classic-card.tsx` were themselves dead
  and were removed.

- **Four template layouts**: Carbon, Beryllium, Helium, and Boron still carried the
  boilerplate's navigation (File Manager, Widgets, Newsletter) and were reachable through
  the settings drawer, giving users a route into template pages. `LAYOUT_OPTIONS` is now
  `HYDROGEN` and `LITHIUM` only. Note that Lithium — not Hydrogen — has always been the
  default that users see, despite the route group being named `(hydrogen)`; a stale
  `isomorphic-layout` value in `localStorage` now falls back to Lithium.

- **Template routes**: `/groups/*` (five stubs rendering literal strings like "AIA"),
  `/auth/sign-in-1..5` and `/auth/sign-up-1..5`, `/widgets/cards`, `/widgets/charts`,
  `/forms/newsletter`, `/file` (an exact duplicate of the home page), and the
  `profile-settings` sub-pages for team, billing, integration, and password.

- **1,415 files, roughly 140,000 lines** in total, including 357 files that only became
  unreachable once the above were gone. Source files under `apps/` and `packages/` dropped
  from 754 to 320. Dead code was identified with an import-reachability walk from the real
  Next.js entry points, checked against runtime `import()` references rather than static
  imports alone — the icon set in `isomorphic-core`, for example, was kept alive solely by a
  template gallery page loading `./icons/${fileName}` at runtime.

- **`tsconfig.tsbuildinfo` untracked**: a 2.2 MB TypeScript build artifact was committed to
  the repository. Added to `.gitignore`.

## Improvements

- **Catch and revenue charts share one implementation**: `catch-time-series` /
  `revenue-time-series` and `catch-radar` / `revenue-radar` were near-identical copies that
  had drifted apart — the catch charts had responsive mobile margins but formatted tooltip
  values with a raw `toFixed(2)`, while the revenue charts ran values through
  `formatDashboardNumber()` and formatted their axes but ignored mobile viewports. They are
  now `metric-time-series` and `metric-radar`, parameterised by the metric the page passes
  in, keeping the better behaviour from each. Shared loading, error, empty, tooltip, and
  legend-toggle logic moved to `charts/chart-common.tsx`. The `/revenue` route bundle fell
  from 5.97 kB to 649 B as a result.

- **Mail service tidied**: removed the `inviteProvider` template — declared but with no
  `.hbs` file, so any use would have thrown — along with its "Please sign up for Rheumote
  Control" subject line and a hardcoded `declan@mountaindev.com` address, both leftovers
  from an unrelated product. `prepTemplate()` and `getTemplate()` no longer duplicate the
  same read-and-cache block. Deleted the unreferenced `resetPasswordAdmin.hbs`.

- **Root layout and tRPC context**: the root layout imported five modules it never used
  (its body is just `return children`). `createTRPCContext` computed `ip` as
  `xForwardedFor ?? xRealIp` where the left operand had already been defaulted to
  `"unknown"`, making the fallback unreachable; it also read an `x-global-filters` header
  that was never used.

- **Documentation**: `CLAUDE.md` updated to describe the single application, the two
  remaining layouts, and the correct dashboard source path.

---

# peskas.dashboard 1.3.1

## Analytics

- **Per-country Google Analytics**: The GA4 measurement ID is now read from
  `NEXT_PUBLIC_GA_MEASUREMENT_ID` per deployment instead of being hardcoded, so each
  country domain reports into its own GA4 property. An optional `NEXT_PUBLIC_GA_ROLLUP_ID`,
  set to the same value on every deployment, mirrors events into a shared property for a
  platform-wide view. Both are declared in `turbo.json` — without that, Turborepo could
  reuse one country's cached build for another and ship the wrong measurement ID.

- **Country dimension on every event**: `peskas_country` and `peskas_country_code` are
  attached globally via `gtag('set')` before `gtag('config')`, so even a shared property can
  be broken down by country. Both must be registered as event-scoped custom dimensions in
  GA4, which does not backfill them.

- **Fixed double-counted page views**: The analytics component re-fired `gtag('config')` on
  every route change while GA4 enhanced measurement was already tracking History API
  navigations, counting each client-side navigation twice. Page views are now left to
  enhanced measurement alone. Historical page-view figures are inflated.

- **Analytics component is now a Server Component**: Dropping the `usePathname()` /
  `useSearchParams()` hooks also removed an unrelated problem — `useSearchParams()` in the
  root layout with no `<Suspense>` boundary opted statically generated pages into
  client-side rendering.

- **Custom event tracking**: Five events cover the filter and map controls:
  `filter_time_range_change`, `filter_metric_change`, `filter_district_change`,
  `map_basemap_change`, and `map_effort_range_toggle`. They fire through a typed
  `trackEvent()` helper in `src/lib/analytics.ts` that no-ops when no measurement ID is set.
  Events are suppressed when a control is re-set to its current value, and nothing fires on
  mount, hydration, or route-driven state resets.

- **Analytics documentation**: New `apps/isomorphic-i18n/ANALYTICS.md` covers the GA4
  account structure options, required admin setup, the event and parameter reference, and
  verification steps. `COUNTRY_SETUP.md` now includes the analytics step when adding a
  country.

---

# peskas.dashboard 1.3.0

## Infrastructure

- **Multi-country deployment**: Each country (TZ, KE, MZ) deploys as a separate Vercel project
  from the same repository, with `NEXT_PUBLIC_COUNTRY_CODE` and `MONGODB_URI` as the only
  per-project env vars. `MONGODB_URI_COASTS` is shared across all deployments.

- **Fixed `NEXT_PUBLIC_COUNTRY_CODE`**: Renamed env var from `COUNTRY_CODE` to
  `NEXT_PUBLIC_COUNTRY_CODE`. The previous name was `undefined` in all client components
  (Next.js only exposes `NEXT_PUBLIC_*` vars to the browser bundle), causing the app to
  always fall back to Zanzibar regardless of which country was configured.

- **`gaul2-districts.ts` registry pattern**: Refactored `packages/nosql/src/constants/gaul2-districts.ts`
  to use the same three-country registry pattern as `countryConfig.ts`. Previously only Zanzibar
  data was exported; Kenya and Mozambique were commented out, breaking the district-summary
  API router for those countries.

- **Project renamed**: Project renamed from `peskas.zanzibar.v2` to `peskas.dashboard` to
  reflect its multi-country scope.

---

# peskas.dashboard 1.2.0

## New Features

- **GAUL2 choropleth map**: Homepage map now overlays administrative district boundaries
  colour-coded by the currently selected metric (CPUE, RPUE, catch tonnage, estimated
  revenue, or submission count). Boundaries are fetched from a separate portal MongoDB
  database (`wio_gaul2` collection) via a new `MONGODB_URI_COASTS` environment variable.
  Colour scale uses a 6-stop sequential Blues palette linearly interpolated across the
  district value range; districts with no data render in grey. The choropleth reacts in
  real-time to both the metric dropdown and the time range selector.

- **Choropleth tooltip**: Hovering a district polygon on the homepage map shows the
  district name and the selected metric value, formatted with the active locale.

- **Choropleth legend**: The map info panel displays the metric label and a colour ramp
  with min/max values when boundary data is loaded.

## Improvements

- **Shared metric state**: `district-summary-bar.tsx` metric selection is now driven by
  the shared `selectedMetricAtom` (Jotai) instead of local `useState`. The bar chart
  and the choropleth map always reflect the same metric selection.

- **Shared date range utility**: Extracted `computeDateRange()` into `dashboard/utils.ts`.
  Both the district summary bar and the choropleth map use it, eliminating duplicated
  inline date computation.

- **Multi-country boundaries**: `countryConfig.ts` extended with an `iso3Code` field
  (`'TZA'` / `'KEN'` / `'MOZ'`). The choropleth queries boundaries for the active
  country automatically — no code change needed when switching deployments.

- **New tRPC router**: `gaul2Boundaries.getByCountry` — queries `wio_gaul2` across all
  known field name variants (alpha-2 and alpha-3 ISO codes, `iso3_code` / `country` /
  nested `properties.*` fields) with a JS-filter fallback for non-standard documents.
  Returns a standard GeoJSON `FeatureCollection`.

- **Isolated portal DB connection**: `packages/nosql/src/portal-db.ts` manages a
  separate Mongoose connection (`mongoose.createConnection()`) for the portal database,
  fully isolated from the main fisheries DB connection.

---

# peskas.dashboard 1.1.0

## Improvements

- **Navigation**: Removed template artifacts (Groups, Widgets menus; ~130 dead route definitions).
  Routes trimmed to fisheries-only (`catch`, `revenue`, `catch_composition`, `map`, `ask_data`,
  `about`, `settings`, `forms.*`). Duplicate `nav-charts` bug fixed.

- **Dashboard components**: Deleted 23 dead component files (0 imports each). Renamed remaining
  components to kebab-case with descriptive names: `metric-cards`, `district-summary-bar`,
  `district-metrics-table`. `index.tsx` cleaned of dead imports and commented-out code.

- **Type safety**: `MetricBarCard` props fully typed (`MetricConfigEntry`, `MetricDataPoint`,
  `MonthlyRegionData`); removed `any` annotations. Badge configuration moved to `DropdownItemType`
  (`badge?: 'beta' | 'soon'`) instead of fragile string-key checks.

- **i18n**: Added `text-district-metrics`, `text-coming-soon`, `text-feature-under-development`
  keys in both English and Swahili. Nav keys (`nav-settings`, `nav-catch-overview`) aligned.
  New `ComingSoonPlaceholder` client component for placeholder pages.

- **Code quality**: `'use client'` directives made explicit; `lang!` assertions replaced with
  `lang ?? 'en'` throughout; unused imports removed.

---

# peskas.dashboard 1.0.0

## Major Changes

- **Multi-country dashboard**: Internationalized Next.js dashboard (apps/isomorphic-i18n)
  for Peskas fisheries deployments. Country is selected via `COUNTRY_CODE` at build
  time; each deployment uses its own config in `countryConfig.ts` and MongoDB,
  with no code fork required.

- **Unified time range for charts**: Navbar time range selector drives all time-based
  charts. Radar (catch and revenue seasonality) now use the same time range as time
  series and treemaps instead of a hardcoded year.

## Improvements

- **Navigation**: Ask Data, Settings, and Map entries can be hidden from nav and
  search (Hydrogen, Lithium, Boron layouts and page-links) for country-specific
  deployments.

- **API**: `monthlySummary.radarData` accepts a `months` parameter (date range)
  instead of a single `year`, returning an array of month-labeled points for the
  selected range. Month labels include the year when the range spans two years.

- **Documentation**: Added `COUNTRY_SETUP.md` for adding a new country to the
  dashboard (config, env, locales, deploy).

## Bug Fixes

- None in this release.

---

# peskas.dashboard 0.1.0

## New Features

- Turborepo monorepo with Next.js 14+ App Router, tRPC API, and MongoDB (nosql).
- Fisheries dashboard with catch, revenue, catch composition, district filters,
  and time range selector.
- Multiple layout themes (Hydrogen, Lithium, Carbon, Beryllium, Boron).
- Shared packages: isomorphic-core (UI), api (tRPC routers), nosql (schemas).

## Improvements

- Tailwind CSS styling; type-safe tRPC procedures; NextAuth integration.
